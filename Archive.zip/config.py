# config.py
DATABASE_URL = "postgresql://allamuchy:Igor-1723@localhost:5432/allamuchy_cars"
